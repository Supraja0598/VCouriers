package com.project.demo.service;

public interface ParcelManagementService {

}