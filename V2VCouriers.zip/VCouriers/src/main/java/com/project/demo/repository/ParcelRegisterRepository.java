package com.project.demo.repository;

import com.project.demo.model.entity.ParcelRegister;
import com.project.demo.model.entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;

@Repository
@Transactional
public interface ParcelRegisterRepository extends JpaRepository<ParcelRegister, Long> {

    List<ParcelRegister> findByUserId(long id);

    Page<ParcelRegister> findByUserId(long id, Pageable pageable);

    ParcelRegister findByName(String name);

    ParcelRegister findByNameAndUser(String name, User user);

    Long countByUserId(long userId);

}