package com.project.demo.service;

import com.project.demo.model.entity.User;

public interface SecurityService {

    boolean hasPermissions(User user, long userId);
    boolean hasAdminPermissions(User user);

}