package com.project.demo.model.base;

public abstract class BaseDto {


}
