package com.project.demo.service;

import com.project.demo.model.entity.User;

public interface AuthService {

    void register(User user);

}