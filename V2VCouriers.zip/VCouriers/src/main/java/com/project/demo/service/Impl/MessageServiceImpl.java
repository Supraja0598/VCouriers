package com.project.demo.service.Impl;


import com.project.demo.model.entity.Message;
import com.project.demo.repository.MessageRepository;
import com.project.demo.service.MessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class MessageServiceImpl implements MessageService {

    @Autowired
    MessageRepository messageRepository;

    @Override
    public List<Message> findByTicketId(long ticketId) {
        return messageRepository.findByTicketId(ticketId);
    }

    @Override
    public Message getById(long messageId) {
        return messageRepository.findOne(messageId);
    }

    @Override
    public void saveOrUpdate(Message message) {
        messageRepository.save(message);
    }
}