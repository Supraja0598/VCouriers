package com.project.demo.service;

import com.project.demo.model.entity.Parcel;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface ParcelService {

    Parcel getById(long id);

    List<Parcel> findByUserId(long userId);

    Page<Parcel> findAllByPage(Pageable pageable);

    void saveOrUpdate(Parcel ticket);

    Page<Parcel> findByUserId(long userId, Pageable pageable);

    Long countByUserId(long userId);

    Long count();

}