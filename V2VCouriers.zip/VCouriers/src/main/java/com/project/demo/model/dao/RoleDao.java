package com.project.demo.model.dao;

import com.project.demo.model.base.BaseDto;
import com.project.demo.model.entity.Role;

import java.util.ArrayList;
import java.util.List;

public class RoleDao extends BaseDto {

    private String name;

    public RoleDao() {
    }

    public RoleDao(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "RoleDto{" +
                "name='" + name + '\'' +
                '}';
    }

    public static RoleDao toDto(Role role) {
        return new RoleDao(role.getName());
    }

    public static List<RoleDao> toDto(List<Role> roles) {
        List<RoleDao> roleDtoList = new ArrayList<>();

        for (Role role : roles) {
            roleDtoList.add(RoleDao.toDto(role));
        }

        return roleDtoList;
    }

}