package com.project.demo.repository;

import com.project.demo.model.entity.Parcel;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;

@Repository
@Transactional
public interface ParcelRepository extends JpaRepository<Parcel, Long> {

    List<Parcel> findByUserId(long id);

    Page<Parcel> findByUserId(long id, Pageable pageable);

    Long countByUserId(long userId);

}
