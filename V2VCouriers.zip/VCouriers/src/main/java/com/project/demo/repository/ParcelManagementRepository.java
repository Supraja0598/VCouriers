package com.project.demo.repository;

public interface ParcelManagementRepository {
}