package com.project.demo.service.Impl;

import com.project.demo.model.entity.ParcelRegister;
import com.project.demo.model.entity.User;
import com.project.demo.repository.ParcelRegisterRepository;
import com.project.demo.service.ParcelRegisterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class ParcelRegisterServiceImpl implements ParcelRegisterService {

    @Autowired
    private ParcelRegisterRepository addressRepository;

    @Override
    public List<ParcelRegister> findByUserId(long userId) {
        return addressRepository.findByUserId(userId);
    }

    @Override
    public void saveOrUpdate(ParcelRegister address) {
        addressRepository.save(address);
    }

    @Override
    public ParcelRegister findByName(String name) {
        return addressRepository.findByName(name);
    }

    @Override
    public ParcelRegister findByNameAndUser(String name, User user) {
        return addressRepository.findByNameAndUser(name, user);
    }

    @Override
    public ParcelRegister findOne(long addressId) {
        return addressRepository.findOne(addressId);
    }

    @Override
    public Page<ParcelRegister> findAllByPage(Pageable pageable) {
        return addressRepository.findAll(pageable);
    }

    @Override
    public Page<ParcelRegister> findByUserId(long userId, Pageable pageable) {
        return addressRepository.findByUserId(userId, pageable);
    }

    @Override
    public Long count() {
        return addressRepository.count();
    }

    @Override
    public void delete(long addressId) {
        addressRepository.deleteById(addressId);
    }

    @Override
    public Long countByUserId(long userId) {
        return addressRepository.countByUserId(userId);
    }
}