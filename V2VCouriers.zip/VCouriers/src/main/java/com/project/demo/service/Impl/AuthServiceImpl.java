package com.project.demo.service.Impl;

import com.project.demo.model.entity.User;
import com.project.demo.repository.AuthRepository;
import com.project.demo.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class AuthServiceImpl implements AuthService {

    @Autowired
    private AuthRepository authRepository;

    @Override
    public void register(User user) {
        authRepository.save(user);
    }

}