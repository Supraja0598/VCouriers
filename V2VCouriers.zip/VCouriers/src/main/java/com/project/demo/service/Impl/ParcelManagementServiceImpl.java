package com.project.demo.service.Impl;

public class ParcelManagementServiceImpl {

}