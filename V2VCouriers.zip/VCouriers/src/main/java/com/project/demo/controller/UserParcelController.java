package com.project.demo.controller;

import com.project.demo.model.dao.ErrorResponseDao;
import com.project.demo.model.dao.MessageDao;
import com.project.demo.model.dao.ParcelDao;
import com.project.demo.model.entity.Message;
import com.project.demo.model.entity.Parcel;
import com.project.demo.model.entity.User;
import com.project.demo.service.MessageService;
import com.project.demo.service.ParcelService;
import com.project.demo.service.UserService;
import com.project.demo.utils.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@RestController
@RequestMapping(Constants.API_URL + Constants.URL_USER_TICKETS)
public class UserParcelController {

    private static final Logger LOGGER = LoggerFactory.getLogger(UserParcelController.class);

    private final ParcelService ticketService;
    private final MessageService messageService;
    private final UserService userService;

    @Autowired
    public UserParcelController(ParcelService ticketService, UserService userService, MessageService messageService) {
        this.ticketService = ticketService;
        this.userService = userService;
        this.messageService = messageService;
    }

    @PreAuthorize("@securityServiceImpl.hasPermissions(#userPrincipal, #userId)")
    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<?> getTickets(@AuthenticationPrincipal User userPrincipal,
                                        @PathVariable("user_id") long userId, Pageable pageable) {
        Page<Parcel> tickets = ticketService.findByUserId(userId, pageable);
        Page<ParcelDao> ticketsDtos = tickets.map(ParcelDao::toDto);
        return new ResponseEntity<>(ticketsDtos, HttpStatus.OK);
    }

    @PreAuthorize("@securityServiceImpl.hasPermissions(#userPrincipal, #userId)")
    @RequestMapping(value = "/all", method = RequestMethod.GET)
    public ResponseEntity<?> getTickets(@AuthenticationPrincipal User userPrincipal,
                                        @PathVariable("user_id") long userId) {
        List<Parcel> tickets = ticketService.findByUserId(userId);
        List<ParcelDao> ticketsDtos = ParcelDao.toDto(tickets);
        return new ResponseEntity<>(ticketsDtos, HttpStatus.OK);
    }

    @PreAuthorize("@securityServiceImpl.hasPermissions(#userPrincipal, #userId)")
    @RequestMapping(value = "/{ticket_id}", method = RequestMethod.GET)
    @ResponseBody
    public ResponseEntity<?> getTicketById(@AuthenticationPrincipal User userPrincipal,
                                           @PathVariable("ticket_id") long ticketId,
                                           @PathVariable("user_id") long userId) {
        Parcel ticket = ticketService.getById(ticketId);

        if (ticket == null) {
            return new ResponseEntity<>("Ticket not found", HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(ParcelDao.toDto(ticket), HttpStatus.OK);
    }

    @PreAuthorize("@securityServiceImpl.hasPermissions(#userPrincipal, #userId)")
    @RequestMapping(method = RequestMethod.POST)
    @ResponseBody
    public ResponseEntity<?> addTicket(@AuthenticationPrincipal User userPrincipal,
                                       @RequestBody ParcelDao ticketDto,
                                       @PathVariable("user_id") long userId) {
        User user = userService.findOne(userPrincipal.getId());

        ticketDto.setStatus("New");
        Parcel ticket = Parcel.toEntity(ticketDto);
        ticket.setUser(user);
        user.getTickets().add(ticket);
        userService.saveOrUpdate(user);

        // TODO return DTO of the newly created ticket
        return new ResponseEntity<>(ticketDto, HttpStatus.CREATED);
    }

    @PreAuthorize("@securityServiceImpl.hasPermissions(#userPrincipal, #userId)")
    @RequestMapping(value = "/{ticket_id}/messages", method = RequestMethod.POST)
    @ResponseBody
    public ResponseEntity<?> addMessage(@AuthenticationPrincipal User userPrincipal,
                                        @RequestBody MessageDao messageDto,
                                        @PathVariable("ticket_id") long ticketId,
                                        @PathVariable("user_id") long userId) {

        if (messageDto.getMsg().isEmpty()) {
            ErrorResponseDao error = new ErrorResponseDao("Empty", "Message is empty");
            return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
        }

        User user = userService.findOne(userPrincipal.getId());
        Parcel ticket = ticketService.getById(ticketId);

        Message message = Message.toEntity(messageDto);
        message.setTicket(ticket);
        message.setUser(user);
        ticket.getMessages().add(message);
        ticket.setLastModifiedDate(new Date());
        user.getMessages().add(message);
        user.getTickets().add(ticket);
        userService.saveOrUpdate(user);

        return new ResponseEntity<>(ParcelDao.toDto(ticket), HttpStatus.CREATED);
    }

}