package com.project.demo.model.dao;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.project.demo.model.base.BaseDto;
import com.project.demo.model.entity.Order;

import java.util.ArrayList;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class OrderDao extends BaseDto {

    private long id;
    private long date;
    private String description;
    private Double price;
    private String status;
    private ParcelRegisterDao addressFrom;
    private ParcelRegisterDao addressTo;
    private UserDao courier;
    private UserDao customer;
    // todo add array of requestDto

    public OrderDao() {
    }

    public OrderDao(long id, long date, String description, Double price, String status, ParcelRegisterDao addressFrom, ParcelRegisterDao addressTo) {
        this.id = id;
        this.date = date;
        this.description = description;
        this.price = price;
        this.status = status;
        this.addressFrom = addressFrom;
        this.addressTo = addressTo;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public UserDao getCourier() {
        return courier;
    }

    public void setCourier(UserDao courier) {
        this.courier = courier;
    }

    public UserDao getCustomer() {
        return customer;
    }

    public void setCustomer(UserDao customer) {
        this.customer = customer;
    }

    public ParcelRegisterDao getAddressFrom() {
        return addressFrom;
    }

    public void setAddressFrom(ParcelRegisterDao addressFrom) {
        this.addressFrom = addressFrom;
    }

    public long getDate() {
        return date;
    }

    public void setDate(long date) {
        this.date = date;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public ParcelRegisterDao getAddressTo() {
        return addressTo;
    }

    public void setAddressTo(ParcelRegisterDao addressTo) {
        this.addressTo = addressTo;
    }

    public static OrderDao toDto(Order order) {
        OrderDao orderDto = new OrderDao();

        if (order.getAddressFrom() != null) {
            orderDto.setAddressFrom(ParcelRegisterDao.toDto(order.getAddressFrom()));
        }
        if (order.getAddressTo() != null) {
            orderDto.setAddressTo(ParcelRegisterDao.toDto(order.getAddressTo()));
        }
        if (order.getCourier() != null) {
            orderDto.setCourier(UserDao.toDto(order.getCourier()));
        }

        orderDto.setId(order.getId());
        orderDto.setDate(order.getDate().getTime() / 1000);
        orderDto.setDescription(order.getDescription());
        orderDto.setPrice(order.getPrice());
        orderDto.setStatus(order.getStatus());
        orderDto.setCustomer(UserDao.toDto(order.getUser()));

        return orderDto;
    }

    public static List<OrderDao> toDto(List<Order> orders) {
        List<OrderDao> ordersDtos = new ArrayList<>();

        for (Order order : orders) {
            ordersDtos.add(OrderDao.toDto(order));
        }

        return ordersDtos;
    }

}
