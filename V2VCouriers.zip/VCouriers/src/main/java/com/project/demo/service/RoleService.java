package com.project.demo.service;

import com.project.demo.model.entity.Role;

public interface RoleService {

    Role findRole(long id);

}
