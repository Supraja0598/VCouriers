package com.project.demo.model.dao;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.project.demo.model.base.BaseDto;
import com.project.demo.model.entity.Invoice;

import java.util.ArrayList;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class InvoiceDao extends BaseDto {

    @JsonProperty("id")
    private long id;

    @JsonProperty("status")
    private String status;

    @JsonProperty("total")
    private Double total;

    @JsonProperty("paid")
    private Double paid;

    @JsonProperty("service_tax")
    private Double tax;

    @JsonProperty("customer")
    private UserDao customer;

    @JsonProperty("courier")
    private UserDao courier;

    @JsonProperty("order")
    private OrderDao order;

    public InvoiceDao() {
    }

    public InvoiceDao(long id, String status, Double total, Double paid, Double tax, UserDao customer, UserDao courier, OrderDao order) {
        this.id = id;
        this.status = status;
        this.total = total;
        this.paid = paid;
        this.tax = tax;
        this.customer = customer;
        this.courier = courier;
        this.order = order;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }

    public Double getPaid() {
        return paid;
    }

    public void setPaid(Double paid) {
        this.paid = paid;
    }

    public Double getTax() {
        return tax;
    }

    public void setTax(Double tax) {
        this.tax = tax;
    }

    public UserDao getCustomer() {
        return customer;
    }

    public void setCustomer(UserDao customer) {
        this.customer = customer;
    }

    public UserDao getCourier() {
        return courier;
    }

    public void setCourier(UserDao courier) {
        this.courier = courier;
    }

    public OrderDao getOrder() {
        return order;
    }

    public void setOrder(OrderDao order) {
        this.order = order;
    }

    public static InvoiceDao toDto(Invoice invoice) {
        UserDao customer = UserDao.toDto(invoice.getUser());
        UserDao courier = UserDao.toDto(invoice.getCourier());
        OrderDao order = OrderDao.toDto(invoice.getOrder());
        return new InvoiceDao(invoice.getId(), invoice.getStatus(), invoice.getTotal(),
                invoice.getPaid(), invoice.getTax(), customer, courier, order);
    }

    public static List<InvoiceDao> toDto(List<Invoice> invoices) {
        List<InvoiceDao> invoiceDtos = new ArrayList<>();

        for (Invoice invoice : invoices) {
            invoiceDtos.add(InvoiceDao.toDto(invoice));
        }

        return invoiceDtos;
    }

}