package com.project.demo.service.Impl;

import com.project.demo.model.entity.ParcelMonitor;
import com.project.demo.repository.ParcelMonitorRepository;
import com.project.demo.service.ParcelMonitorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class ParcelMonitorServiceImpl implements ParcelMonitorService {

    @Autowired
    ParcelMonitorRepository reviewRepository;

    @Override
    public List<ParcelMonitor> findByUserId(long userId) {
        return reviewRepository.findByUserId(userId);
    }

    @Override
    public List<ParcelMonitor> findByCourierId(long courierId) {
        return reviewRepository.findByCourierId(courierId);
    }
}