package com.project.demo.model.dao;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.project.demo.model.base.BaseDto;
import com.project.demo.model.entity.Request;

import java.util.ArrayList;
import java.util.List;

public class RequestDao extends BaseDto {

    @JsonProperty("id")
    private long id;

    @JsonProperty("status")
    private String status;

    @JsonProperty("order")
    private OrderDao order;

    @JsonProperty("courier")
    private UserDao courier;

    @JsonProperty("creation_date")
    private long date;

    public RequestDao() {
    }

    public RequestDao(long id, OrderDao order, UserDao courier, String status, long date) {
        this.id = id;
        this.order = order;
        this.courier = courier;
        this.status = status;
        this.date = date;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public OrderDao getOrder() {
        return order;
    }

    public void setOrder(OrderDao order) {
        this.order = order;
    }

    public UserDao getCourier() {
        return courier;
    }

    public void setCourier(UserDao courier) {
        this.courier = courier;
    }

    public long getDate() {
        return date;
    }

    public void setDate(long date) {
        this.date = date;
    }

    public static RequestDao toDto(Request request) {
        long date = request.getCreatedDate().getTime() / 1000;
        return new RequestDao(request.getId(), OrderDao.toDto(request.getOrder()),
                UserDao.toDto(request.getCourier()), request.getStatus(), date);
    }

    public static List<RequestDao> toDto(List<Request> requests) {
        List<RequestDao> requestsDtos = new ArrayList<>();

        for (Request request : requests) {
            requestsDtos.add(RequestDao.toDto(request));
        }

        return requestsDtos;
    }

}