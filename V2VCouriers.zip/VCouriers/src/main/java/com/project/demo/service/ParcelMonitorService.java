package com.project.demo.service;

import com.project.demo.model.entity.ParcelMonitor;

import java.util.List;

public interface ParcelMonitorService {

    List<ParcelMonitor> findByUserId(long userId);

    List<ParcelMonitor> findByCourierId(long courierId);

}
