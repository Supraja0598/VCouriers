package com.project.demo.controller;

import com.project.demo.model.entity.ParcelRegister;
import com.project.demo.model.dao.ErrorResponseDao;
import com.project.demo.model.dao.ParcelRegisterDao;
import com.project.demo.model.entity.Order;
import com.project.demo.model.entity.User;
import com.project.demo.service.ParcelRegisterService;
import com.project.demo.service.UserService;
import com.project.demo.utils.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(Constants.API_URL + Constants.URL_USER_ADDRESS)
public class UserAddressController {

    private static final Logger LOGGER = LoggerFactory.getLogger(UserAddressController.class);

    private final UserService userService;
    private final ParcelRegisterService addressService;

    @Autowired
    public UserAddressController(UserService userService, ParcelRegisterService addressService) {
        this.userService = userService;
        this.addressService = addressService;
    }

    @PreAuthorize("@securityServiceImpl.hasPermissions(#userPrincipal, #userId)")
    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<?> getAddresses(@AuthenticationPrincipal User userPrincipal,
                                          @PathVariable("user_id") long userId, Pageable pageable) {

        LOGGER.info("Start getAddresses user_id: {}", userId);
        Page<ParcelRegister> addresses = addressService.findByUserId(userId, pageable);
        Page<ParcelRegisterDao> addressesDtos = addresses.map(ParcelRegisterDao::toDto);
        return new ResponseEntity<>(addressesDtos, HttpStatus.OK);
    }

    @PreAuthorize("@securityServiceImpl.hasPermissions(#userPrincipal, #userId)")
    @RequestMapping(method = RequestMethod.POST)
    @ResponseBody
    public ResponseEntity<?> addAddress(@AuthenticationPrincipal User userPrincipal,
                                        @PathVariable("user_id") long userId, @RequestBody ParcelRegisterDao addressDto) {
        LOGGER.info("Start addAddress user_id: {}", userId);
        User user = userService.findOne(userId);

        if (user == null) {
            LOGGER.error("User with id {} is not found", userId);
            return new ResponseEntity<>("User not found", HttpStatus.NOT_FOUND);
        }

        ParcelRegister existingAddress = addressService.findByNameAndUser(addressDto.getName(), user);

        if (existingAddress == null) {
            ParcelRegister address = ParcelRegister.toEntity(addressDto);
            address.setUser(user);
            user.getAddresses().add(address);

            userService.saveOrUpdate(user);
            LOGGER.info("new address with name {} and user id {} is successfully created", address.getName(), user.getId());
            return new ResponseEntity<>(addressDto, HttpStatus.CREATED);
        } else {
            LOGGER.info("Address with name {} is already exists", existingAddress.getName());
            ErrorResponseDao error = new ErrorResponseDao("internal", "Address with this name is already exists");
            return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
        }
    }

    @PreAuthorize("@securityServiceImpl.hasPermissions(#userPrincipal, #userId)")
    @RequestMapping(value = "/{id}", method = RequestMethod.PUT)
    @ResponseBody
    public ResponseEntity<?> editAddress(@AuthenticationPrincipal User userPrincipal,
                                         @PathVariable("id") long id,
                                         @PathVariable("user_id") long userId,
                                         @RequestBody ParcelRegisterDao addressDto) {
        ParcelRegister address = addressService.findOne(id);

        if (address == null) {
            ErrorResponseDao error = new ErrorResponseDao("Not found", "Order not found");
            return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
        }

        address.setCity(addressDto.getCity());
        address.setCountry(addressDto.getCountry());
        address.setAddress(addressDto.getAddress());
        address.setName(addressDto.getName());
        address.setPhone(addressDto.getPhone());
        address.setRegion(addressDto.getRegion());
        address.setPostalCode(addressDto.getPostalCode());
        //address.setLatitude(addressDto.getLatitude());
        //address.setLongitude(addressDto.getLongitude());

        addressService.saveOrUpdate(address);
        return new ResponseEntity<>(ParcelRegisterDao.toDto(address), HttpStatus.OK);
    }

    @PreAuthorize("@securityServiceImpl.hasPermissions(#userPrincipal, #userId)")
    @RequestMapping(value = "/{address_id}", method = RequestMethod.DELETE)
    public ResponseEntity<?> deleteAddress(@AuthenticationPrincipal User userPrincipal,
                                           @PathVariable("user_id") long userId,
                                           @PathVariable("address_id") long addressId) {
        LOGGER.info("Start deleteAddress addressId: {}", addressId);
        ParcelRegister address = addressService.findOne(addressId);

        if (address == null) {
            LOGGER.error("Address with id {} is not found", addressId);
            return new ResponseEntity<>("Address not found", HttpStatus.NOT_FOUND);
        }

        // todo add check for order status and if one of the orders has "In progress" status then don't delete address

        for (Order order : address.getOrders()) {
            order.setAddressFrom(null);
        }

        addressService.delete(addressId);
        return new ResponseEntity<>(addressId, HttpStatus.NO_CONTENT);
    }

}