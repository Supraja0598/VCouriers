package com.project.demo.model.dao;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.project.demo.model.base.BaseDto;
import com.project.demo.model.entity.ParcelMonitor;

import java.util.ArrayList;
import java.util.List;

public class ParcelMonitorDao extends BaseDto {

    @JsonProperty("review")
    private String review;

    @JsonProperty("rating")
    private int rating;

    @JsonProperty("user")
    private UserDao user;

    @JsonProperty("courier")
    private UserDao courier;

    public ParcelMonitorDao() { }

    public ParcelMonitorDao(String review, int rating, UserDao user, UserDao courier) {
        this.review = review;
        this.rating = rating;
        this.user = user;
        this.courier = courier;
    }

    public UserDao getCourier() {
        return courier;
    }

    public void setCourier(UserDao courier) {
        this.courier = courier;
    }

    public String getReview() {
        return review;
    }

    public void setReview(String review) {
        this.review = review;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public UserDao getUser() {
        return user;
    }

    public void setUser(UserDao user) {
        this.user = user;
    }

    @Override
    public String toString() {
        return "ReviewDto{" +
                "review='" + review + '\'' +
                ", rating=" + rating +
                ", user=" + user +
                '}';
    }

    public static ParcelMonitorDao toDto(ParcelMonitor review) {
        return new ParcelMonitorDao(review.getReview(), review.getRating(),
                UserDao.toDto(review.getUser()), UserDao.toDto(review.getCourier()));
    }

    public static List<ParcelMonitorDao> toDto(List<ParcelMonitor> reviews) {
        List<ParcelMonitorDao> reviewsDto = new ArrayList<>();

        for (ParcelMonitor review : reviews) {
            reviewsDto.add(ParcelMonitorDao.toDto(review));
        }

        return reviewsDto;
    }

}