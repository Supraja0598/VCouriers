package com.project.demo.controller;

import com.project.demo.model.entity.ParcelRegister;
import com.project.demo.model.dao.ParcelRegisterDao;
import com.project.demo.model.entity.Order;
import com.project.demo.model.entity.User;
import com.project.demo.service.ParcelRegisterService;
import com.project.demo.utils.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(Constants.API_URL + Constants.URL_ADDRESSES)
public class ParcelRegisterController {

    private static final Logger LOGGER = LoggerFactory.getLogger(ParcelRegisterController.class);

    private final ParcelRegisterService addressService;

    @Autowired
    public ParcelRegisterController(ParcelRegisterService addressService) {
        this.addressService = addressService;
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    @ResponseBody
    public ResponseEntity<?> getAddressById(@PathVariable("id") long id) {
        LOGGER.info("Start getAddressById with id: {}", id);
        ParcelRegister address = addressService.findOne(id);

        if (address == null) {
            LOGGER.info("Address with id: {} is NULL", id);
            return new ResponseEntity<>("Address not found", HttpStatus.NOT_FOUND);
        }

        ParcelRegisterDao addressDto = ParcelRegisterDao.toDto(address);
        return new ResponseEntity<>(addressDto, HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<?> getAddresses(Pageable pageable) {
        Page<ParcelRegister> addresses = addressService.findAllByPage(pageable);
        Page<ParcelRegisterDao> addressesDtos = addresses.map(ParcelRegisterDao::toDto);
        return new ResponseEntity<>(addressesDtos, HttpStatus.OK);
    }

    @PreAuthorize("@securityServiceImpl.hasAdminPermissions(#userPrincipal)")
    @RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
    public ResponseEntity<?> deleteAddress(@AuthenticationPrincipal User userPrincipal,
                                           @PathVariable("id") long id) {
        LOGGER.info("Start deleteAddress");
        ParcelRegister address = addressService.findOne(id);

        if (address == null) {
            LOGGER.error("Address with id {} is not found", id);
            return new ResponseEntity<>("Address not found", HttpStatus.NOT_FOUND);
        }

        // todo also maybe only set "disabled/deleted" property to true and doesn't show to user instead of deleting
        // todo add check for order status and if one of the orders has "In progress" status then don't delete address

        for (Order order : address.getOrders()) {
            //order.setAddressFrom(null);
            // todo
        }

        addressService.delete(id);
        return new ResponseEntity<>(id, HttpStatus.NO_CONTENT);
    }

}
