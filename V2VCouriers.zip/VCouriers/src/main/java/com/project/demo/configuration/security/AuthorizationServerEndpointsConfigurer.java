package com.project.demo.configuration.security;

public class AuthorizationServerEndpointsConfigurer {

}
