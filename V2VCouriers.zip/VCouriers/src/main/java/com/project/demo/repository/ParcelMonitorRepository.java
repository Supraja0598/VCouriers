package com.project.demo.repository;

import com.project.demo.model.entity.ParcelMonitor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ParcelMonitorRepository extends JpaRepository<ParcelMonitor, Long> {

    List<ParcelMonitor> findByUserId(long id);

    List<ParcelMonitor> findByCourierId(long id);

}