package com.project.demo.location;

public class LocationResource {

}
