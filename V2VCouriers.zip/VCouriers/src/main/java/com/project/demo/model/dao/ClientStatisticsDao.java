package com.project.demo.model.dao;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.project.demo.model.base.BaseDto;

public class ClientStatisticsDao extends BaseDto {

    @JsonProperty("active_orders_count")
    private long activeOrdersCount;

    @JsonProperty("orders_count")
    private long ordersCount;

    @JsonProperty("addresses_count")
    private long addressesCount;

    @JsonProperty("tickets_count")
    private long ticketsCounts;

    public ClientStatisticsDao() {
    }

    public ClientStatisticsDao(long activeOrdersCount, long ordersCount, long addressesCount, long ticketsCounts) {
        this.activeOrdersCount = activeOrdersCount;
        this.ordersCount = ordersCount;
        this.addressesCount = addressesCount;
        this.ticketsCounts = ticketsCounts;
    }

    public long getActiveOrdersCount() {
        return activeOrdersCount;
    }

    public void setActiveOrdersCount(long activeOrdersCount) {
        this.activeOrdersCount = activeOrdersCount;
    }

    public long getOrdersCount() {
        return ordersCount;
    }

    public void setOrdersCount(long ordersCount) {
        this.ordersCount = ordersCount;
    }

    public long getAddressesCount() {
        return addressesCount;
    }

    public void setAddressesCount(long addressesCount) {
        this.addressesCount = addressesCount;
    }

    public long getTicketsCounts() {
        return ticketsCounts;
    }

    public void setTicketsCounts(long ticketsCounts) {
        this.ticketsCounts = ticketsCounts;
    }
}