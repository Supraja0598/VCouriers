package com.project.demo.service;

import com.project.demo.model.entity.Message;

import java.util.List;

public interface MessageService {

    List<Message> findByTicketId(long ticketId);

    Message getById(long messageId);

    void saveOrUpdate(Message message);

}