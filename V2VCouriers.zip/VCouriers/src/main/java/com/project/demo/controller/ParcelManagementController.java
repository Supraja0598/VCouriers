package com.project.demo.controller;

import com.project.demo.model.dao.ClientStatisticsDao;
import com.project.demo.model.dao.ParcelManagementDao;
import com.project.demo.model.entity.User;
import com.project.demo.service.ParcelRegisterService;
import com.project.demo.service.OrderService;
import com.project.demo.service.ParcelService;
import com.project.demo.service.UserService;
import com.project.demo.utils.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(Constants.API_URL + Constants.URL_STATISTICS)
public class ParcelManagementController {

    private static final Logger LOGGER = LoggerFactory.getLogger(ParcelManagementController.class);

    private final UserService userService;
    private final OrderService orderService;
    private final ParcelRegisterService addressService;
    private final ParcelService parcelService;

    @Autowired
    public ParcelManagementController(UserService userService, OrderService orderService,
                               ParcelRegisterService addressService, ParcelService ticketService, ParcelService parcelService) {
        this.userService = userService;
        this.orderService = orderService;
        this.addressService = addressService;
        this.parcelService = parcelService;
    }

    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<?> getStatistic() {
        LOGGER.info("Start getStatistics");
        Long usersCount = userService.count();
        Long ordersCount = orderService.count();
        Long addressesCount = addressService.count();
        Long parcelsCount = parcelService.count();
        ParcelManagementDao statisticsDto = new ParcelManagementDao(usersCount, ordersCount, addressesCount, parcelsCount);
        return new ResponseEntity<>(statisticsDto, HttpStatus.OK);
    }

    @PreAuthorize("@securityServiceImpl.hasPermissions(#userPrincipal, #userId)")
    @RequestMapping(value = "/{user_id}", method = RequestMethod.GET)
    public ResponseEntity<?> getStatistic(@AuthenticationPrincipal User userPrincipal,
                                          @PathVariable("user_id") long userId) {
        Long ordersCount = orderService.countByUserId(userId);
        Long addressesCount = addressService.countByUserId(userId);
        Long ticketsCount = parcelService.countByUserId(userId);
        String status = "In progress";
        Long activeOrdersCount = orderService.countByUserIdAndStatus(userId, status);
        ClientStatisticsDao statisticsDto = new ClientStatisticsDao(activeOrdersCount, ordersCount, addressesCount, ticketsCount);
        return new ResponseEntity<>(statisticsDto, HttpStatus.OK);
    }

}