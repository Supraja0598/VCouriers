package com.project.demo.service;

import com.project.demo.model.entity.ParcelRegister;
import com.project.demo.model.entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface ParcelRegisterService {

    List<ParcelRegister> findByUserId(long userId);

    Page<ParcelRegister> findAllByPage(Pageable pageable);

    Page<ParcelRegister> findByUserId(long userId, Pageable pageable);

    void saveOrUpdate(ParcelRegister address);

    ParcelRegister findByName(String name);

    ParcelRegister findByNameAndUser(String name, User user);

    ParcelRegister findOne(long addressId);

    void delete(long addressId);

    Long count();

    Long countByUserId(long userId);

}