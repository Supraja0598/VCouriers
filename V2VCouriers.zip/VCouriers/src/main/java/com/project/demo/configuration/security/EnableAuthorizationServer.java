package com.project.demo.configuration.security;

public @interface EnableAuthorizationServer {

}
