package com.project.demo.model.dao;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.project.demo.model.base.BaseDto;
import com.project.demo.model.entity.Parcel;

import java.util.ArrayList;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ParcelDao extends BaseDto {

    @JsonProperty("id")
    private long id;

    @JsonProperty("status")
    private String status;

    @JsonProperty("title")
    private String title;

    @JsonProperty("created_date")
    private long created_date;

    @JsonProperty("updated_date")
    private long updated_date;

    @JsonProperty("user")
    private UserDao user;

    public ParcelDao() {
    }

    public ParcelDao(long id, String status, String title, long created_date, long updated_date, UserDao user) {
        this.id = id;
        this.status = status;
        this.title = title;
        this.created_date = created_date;
        this.updated_date = updated_date;
        this.user = user;
    }

    public UserDao getUser() {
        return user;
    }

    public void setUser(UserDao user) {
        this.user = user;
    }

    public long getCreated_date() {
        return created_date;
    }

    public void setCreated_date(long created_date) {
        this.created_date = created_date;
    }

    public long getUpdated_date() {
        return updated_date;
    }

    public void setUpdated_date(long updated_date) {
        this.updated_date = updated_date;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public static ParcelDao toDto(Parcel ticket) {
        return new ParcelDao(ticket.getId(), ticket.getStatus(), ticket.getTitle(),
                ticket.getCreatedDate().getTime() / 1000,
                ticket.getLastModifiedDate().getTime() / 1000,
                UserDao.toDto(ticket.getUser()));
    }

    public static List<ParcelDao> toDto(List<Parcel> tickets) {
        List<ParcelDao> ticketsDtos = new ArrayList<>();

        for (Parcel ticket : tickets) {
            ticketsDtos.add(ParcelDao.toDto(ticket));
        }

        return ticketsDtos;
    }

}